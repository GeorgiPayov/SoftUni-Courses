﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OOP_Inheritance
{
    public class Child : Person
    {
        public Child (string name, int age)
            : base(name, age)
        {

        }
    }
}
