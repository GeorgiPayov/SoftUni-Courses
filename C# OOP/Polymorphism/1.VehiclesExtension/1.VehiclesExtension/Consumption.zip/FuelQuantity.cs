﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _1.VehiclesExtension
{
    public interface FuelQuantity
    {
        public double FuelQuantity { get; set; }
    }
}
