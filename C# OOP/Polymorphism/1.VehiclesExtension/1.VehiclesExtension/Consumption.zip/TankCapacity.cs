﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _1.VehiclesExtension
{
    public interface TankCapacity
    {
        public int TankCapacity { get; set; }
    }
}
