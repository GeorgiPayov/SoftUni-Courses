﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _1.VehiclesExtension
{
    public interface Consumption
    {
        public double Consumption { get; set; }
    }
}
