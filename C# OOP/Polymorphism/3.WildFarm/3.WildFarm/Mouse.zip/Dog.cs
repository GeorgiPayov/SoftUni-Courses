﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3.WildFarm
{
    public class Dog : Mammal
    {
        public Dog(string name, double weight, int foodEaten, string livingRegion) : 
            base(name, weight, foodEaten, livingRegion)
        {
        }

        public override void ToString()
        {
            Console.WriteLine($"Dog [{Name}, {Weight}, {LivingRegion}, {FoodEaten}]");
        }

        public override string ProduceSound()
        {
            return "Woof!";
        }
    }
}
