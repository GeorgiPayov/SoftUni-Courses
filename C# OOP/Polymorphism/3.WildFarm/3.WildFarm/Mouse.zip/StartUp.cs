﻿using System;

namespace _3.WildFarm
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            string[] animalInfo = Console.ReadLine().Split();

            while(animalInfo[0] != "End")
            {
                string animalType = animalInfo[0];
                string animalName = animalInfo[1];
                double animalWeight = double.Parse(animalInfo[2]);

                string[] foodInfo = Console.ReadLine().Split();
                string food = foodInfo[0];
                int quantity = int.Parse(foodInfo[1]);

                if (animalType == "Owl")
                {
                    double wingSize = double.Parse(animalInfo[3]);
                    Owl owl = new Owl(animalName, animalWeight, 0, wingSize);
                    Console.WriteLine(owl.ProduceSound());
                    
                    if (food == "Meat")
                    {
                        owl.FoodEaten += quantity;
                        owl.Weight += quantity * 0.25;
                        owl.ToString();
                    }
                    else
                    {
                        Console.WriteLine($"Owl does not eat {food}!");
                    }
                }
                else if (animalType == "Hen")
                {
                    double wingSize = double.Parse(animalInfo[3]);
                    Hen hen = new Hen(animalName, animalWeight, quantity, wingSize);
                    hen.Weight += quantity * 0.35;

                    Console.WriteLine(hen.ProduceSound());
                    hen.ToString();
                }
                else if (animalType == "Mouse")
                {
                    string livingRegion = animalInfo[3];
                    Mouse mouse = new Mouse(animalName, animalWeight, 0, livingRegion);

                    Console.WriteLine(mouse.ProduceSound());

                    if (food == "Vegetable")
                    {
                        mouse.FoodEaten += quantity;
                        mouse.Weight += quantity * 0.10;
                        mouse.ToString();
                    }
                    else if (food == "Fruit")
                    {
                        mouse.FoodEaten += quantity;
                        mouse.Weight += quantity * 0.10;
                        mouse.ToString();
                    }
                    else
                    {
                        Console.WriteLine($"Mouse does not eat {food}!");
                    }
                }
                else if (animalType == "Dog")
                {
                    string livingRegion = animalInfo[3];
                    Dog dog = new Dog(animalName, animalWeight, 0, livingRegion);

                    Console.WriteLine(dog.ProduceSound());

                    if (food == "Meat")
                    {
                        dog.FoodEaten += quantity;
                        dog.Weight += quantity * 0.40;
                        dog.ToString();
                    }
                    else
                    {
                        Console.WriteLine($"Dog does not eat {food}!");
                    }
                }
                else if (animalType == "Cat")
                {
                    string livingRegion = animalInfo[3];
                    string breed = animalInfo[4];
                    Cat cat = new Cat(animalName, animalWeight, 0, livingRegion, breed);

                    Console.WriteLine(cat.ProduceSound());

                    if (food == "Vegetable")
                    {
                        cat.FoodEaten += quantity;
                        cat.Weight += quantity * 0.30;
                        cat.ToString();
                    }
                    else if (food == "Meat")
                    {
                        cat.FoodEaten += quantity;
                        cat.Weight += quantity * 0.30;
                        cat.ToString();
                    }
                    else
                    {
                        Console.WriteLine($"Cat does not eat {food}!");
                    }
                }
                else if (animalType == "Tiger")
                {
                    string livingRegion = animalInfo[3];
                    string breed = animalInfo[4];
                    Tiger tiger = new Tiger(animalName, animalWeight, 0, livingRegion, breed);

                    Console.WriteLine(tiger.ProduceSound());

                    if (food == "Meat")
                    {
                        tiger.FoodEaten += quantity;
                        tiger.Weight += quantity * 1;
                        tiger.ToString();
                    }
                    else
                    {
                        Console.WriteLine($"Tiger does not eat {food}!");
                    }
                }


                animalInfo = Console.ReadLine().Split();
            }

        }
    }
}
