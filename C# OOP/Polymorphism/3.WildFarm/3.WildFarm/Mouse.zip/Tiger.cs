﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3.WildFarm
{
    public class Tiger : Feline
    {
        public Tiger(string name, double weight, int foodEaten, string livingRegion, string breed) :
            base(name, weight, foodEaten, livingRegion, breed)
        {
        }

        public override string ProduceSound()
        {
            return "ROAR!!!";
        }

        public override void ToString()
        {
            Console.WriteLine($"Tiger [{Name}, {Breed}, {Weight}, {LivingRegion}, {FoodEaten}]");
        }

    }
}
