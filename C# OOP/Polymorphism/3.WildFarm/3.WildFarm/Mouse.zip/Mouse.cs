﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3.WildFarm
{
    public class Mouse : Mammal
    {
        public Mouse(string name, double weight, int foodEaten, string livingRegion) :
            base(name, weight, foodEaten, livingRegion)
        {
        }

        public override void ToString()
        {
            Console.WriteLine($"Mouse [{Name}, {Weight}, {LivingRegion}, {FoodEaten}]");
        }

        public override string ProduceSound()
        {
            return "Squeak";
        }
    }
}
