﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _3.WildFarm
{
    public interface IFood
    {
        public int Quantity { get; set; }
    }
}
